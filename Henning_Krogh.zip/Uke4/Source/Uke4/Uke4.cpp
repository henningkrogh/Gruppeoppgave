// Fill out your copyright notice in the Description page of Project Settings.

#include "Uke4.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Uke4, "Uke4" );
