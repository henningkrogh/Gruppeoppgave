// Fill out your copyright notice in the Description page of Project Settings.

#include "Uke4.h"
#include "Uke4GameModeBase.h"
#include "Enemy.h"

AUke4GameModeBase::AUke4GameModeBase()
{

}

void AUke4GameModeBase::Tick(float DeltaTime)
{
	Super::Tick( DeltaTime );

	
}
